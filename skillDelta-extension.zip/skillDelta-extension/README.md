# SkillDelta Chrome Extension

A Chrome extension that analyzes job descriptions and extracts required skills using AI.

## Features

- **Floating Widget**: Appears on all webpages
- **Clipboard Integration**: Automatically detects copied job descriptions
- **AI Skill Extraction**: Uses OpenAI to identify required skills
- **Quick Analysis**: One-click job analysis
- **Sync to Profile**: Send extracted skills to your main SkillDelta profile

## Installation

### Development Setup

1. **Clone or download the extension files**
   ```bash
   cd skillDelta-extension
   ```

2. **Open Chrome and go to Extensions**
   - Chrome menu → More tools → Extensions
   - Enable "Developer mode" (top right)
   - Click "Load unpacked"
   - Select the `skillDelta-extension` folder

3. **Start the Backend**
   ```bash
   # From project root
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   pip install -r requirements.txt
   python -m uvicorn backend.main:app --reload
   ```

4. **Set Environment Variables**
   Create a `.env` file in the project root:
   ```
   OPENAI_API_KEY=your_api_key_here
   ```

## Usage

1. Navigate to any webpage with a job description
2. Copy the job description text to your clipboard
3. Click the **SkillDelta** icon (floating widget in bottom-right corner)
4. Click **"Check Clipboard"** to load the job description
5. Click **"Analyse with AI"** to extract required skills
6. View the extracted skills and click **"Send to App"** to sync with your profile

## Extension Structure

```
skillDelta-extension/
├── manifest.json          # Extension configuration
├── src/
│   ├── background.js      # Service worker (clipboard & API calls)
│   ├── content.js         # Floating widget & UI logic
│   ├── styles.css         # Widget styling
│   └── popup.html         # Extension popup
├── icons/                 # Extension icons
└── README.md
```

## Backend API

### `/api/extract-skills` (POST)

Extracts skills from a job description.

**Request:**
```json
{
  "job_description": "Looking for a React developer with 5+ years experience..."
}
```

**Response:**
```json
{
  "skills": ["React", "JavaScript", "Node.js", "AWS", "Docker"],
  "raw_response": "[\"React\", \"JavaScript\", \"Node.js\", \"AWS\", \"Docker\"]"
}
```

### `/api/match-skills` (POST)

Compares user skills against job requirements.

**Request:**
```json
{
  "user_skills": ["React", "JavaScript", "Python"],
  "job_skills": ["React", "Node.js", "AWS", "Docker"]
}
```

**Response:**
```json
{
  "matched_skills": ["react"],
  "skill_gaps": ["node.js", "aws", "docker"],
  "match_percentage": 25.0,
  "total_required": 4,
  "matched_count": 1
}
```

## Configuration

### Backend URL
The extension is configured to connect to `http://localhost:8000` by default.

To change the backend URL, edit `src/background.js`:
```javascript
const backendUrl = 'http://localhost:8000/api/extract-skills';
```

### OpenAI Model
Currently uses `gpt-3.5-turbo`. To use a different model, edit `backend/main.py`:
```python
model="gpt-3.5-turbo",  # Change this
```

## Dependencies

### Frontend (Extension)
- Chrome Manifest V3
- Vanilla JavaScript
- CSS3

### Backend
- FastAPI
- OpenAI Python SDK
- Python 3.8+

## Known Limitations

- Requires Chrome browser
- Backend must be running locally
- OpenAI API key required
- No authentication (development version)

## Future Enhancements

- [ ] Integration with main SkillDelta profile
- [ ] Real-time skill matching against user profile
- [ ] Roadmap generation for skill gaps
- [ ] Chrome Web Store publication
- [ ] Firefox/Safari support
- [ ] Cloud backend deployment

## Troubleshooting

### Extension not appearing
- Ensure extension is enabled in chrome://extensions
- Try refreshing the webpage

### "Clipboard is empty" error
- Copy a job description text to clipboard
- Try a longer text snippet

### "Failed to analyze" error
- Ensure backend is running: `python -m uvicorn backend.main:app --reload`
- Check backend URL in `src/background.js`
- Verify OpenAI API key is set in `.env`

### CORS errors
- Backend CORS is configured to allow all origins (`allow_origins=["*"]`)
- For production, update CORS settings in `backend/main.py`

## Development

### Debugging Extension
1. Go to `chrome://extensions`
2. Find "SkillDelta" extension
3. Click "Details" → "Errors" to see console errors
4. Inspect using Chrome DevTools on the extension's service worker

### Testing Backend
```bash
# Test health check
curl http://localhost:8000/health

# Test skill extraction
curl -X POST http://localhost:8000/api/extract-skills \
  -H "Content-Type: application/json" \
  -d '{"job_description": "Looking for Python developer with AWS experience"}'
```

## License

See LICENSE file in project root.

## Support

For issues or suggestions, contact the development team or create an issue in the project repository.
