// Background service worker for clipboard monitoring and message handling

console.log('SkillDelta background service worker loaded');

chrome.runtime.onInstalled.addListener(() => {
  console.log('SkillDelta extension installed');
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background received message:', request.action);

  if (request.action === 'getClipboardText') {
    getClipboardText()
      .then(text => {
        console.log('Background: Clipboard text obtained, length:', text.length);
        sendResponse({ success: true, text: text });
      })
      .catch(error => {
        console.error('Background: Clipboard error:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true; // Will respond asynchronously
  }

  if (request.action === 'extractSkills') {
    console.log('Background: Extract skills request');
    extractSkillsFromJobDescription(request.jobDescription)
      .then(skills => {
        console.log('Background: Skills extracted:', skills.length);
        sendResponse({ success: true, skills: skills });
      })
      .catch(error => {
        console.error('Background: Skills extraction error:', error);
        sendResponse({ success: false, error: error.message });
      });
    return true;
  }
});

async function ensureOffscreenDocument() {
  console.log('Ensuring offscreen document exists...');

  try {
    // Check if offscreen document already exists
    const offscreenUrl = chrome.runtime.getURL('src/offscreen.html');
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [offscreenUrl]
    });

    if (existingContexts.length > 0) {
      console.log('Offscreen document already exists');
      return;
    }

    console.log('Creating offscreen document...');
    await chrome.offscreen.createDocument({
      url: 'src/offscreen.html',
      reasons: ['CLIPBOARD'],
      justification: 'Read clipboard text for job description analysis'
    });
    console.log('Offscreen document created successfully');
  } catch (error) {
    console.error('Error ensuring offscreen document:', error);
    throw error;
  }
}

async function getClipboardText() {
  const MESSAGE_TIMEOUT = 10000; // 10 seconds max

  try {
    console.log('getClipboardText: Starting...');

    // Ensure offscreen document exists
    await ensureOffscreenDocument();

    // Send message to offscreen document with timeout
    console.log('getClipboardText: Sending message to offscreen document');

    const responsePromise = chrome.runtime.sendMessage({
      type: 'clipboard',
      target: 'offscreen'
    });

    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Clipboard read timeout')), MESSAGE_TIMEOUT)
    );

    const response = await Promise.race([responsePromise, timeoutPromise]);

    console.log('getClipboardText: Response received:', response);

    if (!response) {
      throw new Error('No response from offscreen document - the offscreen context may have crashed');
    }

    if (response.success === false) {
      const errorMsg = response.error || 'Unknown clipboard error';
      console.error('Offscreen document reported error:', errorMsg);
      throw new Error(errorMsg);
    }

    if (!response.data) {
      throw new Error('Clipboard is empty. Please copy a job description first.');
    }

    const trimmedData = response.data.trim();
    if (trimmedData.length === 0) {
      throw new Error('Clipboard contains only whitespace. Please copy a valid job description.');
    }

    console.log('getClipboardText: Successfully retrieved clipboard data, length:', trimmedData.length);
    return trimmedData;
  } catch (error) {
    console.error('getClipboardText error details:', {
      message: error?.message,
      stack: error?.stack,
      name: error?.name
    });
    throw error;
  }
}

async function extractSkillsFromJobDescription(jobDescription) {
  const backendUrl = 'http://localhost:8000/api/extract-skills';

  try {
    console.log('Extracting skills from job description, length:', jobDescription.length);

    const response = await fetch(backendUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        job_description: jobDescription
      })
    });

    if (!response.ok) {
      throw new Error(`Backend error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    console.log('Skills extracted from backend:', data.skills);
    return data.skills || [];
  } catch (error) {
    console.error('Error extracting skills:', error);
    throw error;
  }
}
