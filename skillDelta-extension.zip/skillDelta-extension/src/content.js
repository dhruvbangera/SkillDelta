// Content script for injecting floating widget into webpages

console.log('SkillDelta: Content script loaded');

// Create and inject floating widget
const createWidget = () => {
  console.log('SkillDelta: Creating widget...');
  const widgetContainer = document.createElement('div');
  widgetContainer.id = 'skillDelta-widget-container';
  widgetContainer.innerHTML = `
    <div id="skillDelta-widget" class="skillDelta-widget">
      <div class="skillDelta-widget-header">
        <span class="skillDelta-widget-title">SkillDelta</span>
        <button id="skillDelta-close-btn" class="skillDelta-close-btn">×</button>
      </div>
      <div class="skillDelta-widget-body">
        <div id="skillDelta-status" class="skillDelta-status">Ready to analyze job descriptions</div>
        <button id="skillDelta-check-clipboard-btn" class="skillDelta-btn-primary">Check Clipboard</button>
        <div id="skillDelta-job-display" class="skillDelta-job-display" style="display: none;">
          <p class="skillDelta-label">Job Description Preview:</p>
          <div id="skillDelta-job-text" class="skillDelta-job-text"></div>
          <button id="skillDelta-analyze-btn" class="skillDelta-btn-analyze">Analyse with AI</button>
          <button id="skillDelta-clear-btn" class="skillDelta-btn-secondary">Clear</button>
        </div>
        <div id="skillDelta-results" class="skillDelta-results" style="display: none;">
          <p class="skillDelta-label">Extracted Skills:</p>
          <div id="skillDelta-skills-list" class="skillDelta-skills-list"></div>
          <button id="skillDelta-send-to-app-btn" class="skillDelta-btn-primary">Send to App</button>
          <button id="skillDelta-new-job-btn" class="skillDelta-btn-secondary">Analyze Another</button>
        </div>
        <div id="skillDelta-loading" class="skillDelta-loading" style="display: none;">
          <div class="skillDelta-spinner"></div>
          <p>Analyzing with AI...</p>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(widgetContainer);
  console.log('SkillDelta: Widget added to DOM');
  setupEventListeners();
};

const setupEventListeners = () => {
  const checkClipboardBtn = document.getElementById('skillDelta-check-clipboard-btn');
  const analyzeBtn = document.getElementById('skillDelta-analyze-btn');
  const clearBtn = document.getElementById('skillDelta-clear-btn');
  const newJobBtn = document.getElementById('skillDelta-new-job-btn');
  const sendToAppBtn = document.getElementById('skillDelta-send-to-app-btn');
  const closeBtn = document.getElementById('skillDelta-close-btn');

  let currentJobDescription = '';

  checkClipboardBtn.addEventListener('click', async () => {
    try {
      console.log('Content script: Reading clipboard...');

      // Try to read clipboard directly from content script
      const text = await navigator.clipboard.readText();
      console.log('Content script: Clipboard text read, length:', text.length);

      if (text && text.trim()) {
        currentJobDescription = text;
        updateStatus('Extracting job details...', 'info');

        // Extract job details and display them
        await extractAndDisplayJobDetails(text);
        updateStatus('✓ Job added to clipboard', 'success');
      } else {
        updateStatus('Clipboard is empty. Please copy a job description.', 'error');
      }
    } catch (error) {
      console.error('Content script: Clipboard error:', error);

      // Fallback: try to get from background service worker
      console.log('Content script: Trying background service worker approach...');
      try {
        const response = await chrome.runtime.sendMessage({
          action: 'getClipboardText'
        });

        if (response.success && response.text.trim()) {
          currentJobDescription = response.text;
          updateStatus('Extracting job details...', 'info');
          await extractAndDisplayJobDetails(response.text);
          updateStatus('✓ Job added to clipboard', 'success');
        } else {
          updateStatus('Clipboard is empty. Please copy a job description.', 'error');
        }
      } catch (fallbackError) {
        console.error('Content script: Fallback also failed:', fallbackError);
        updateStatus('Failed to read clipboard. Make sure you copied text first.', 'error');
      }
    }
  });

  analyzeBtn.addEventListener('click', async () => {
    if (!currentJobDescription) {
      updateStatus('No job description found.', 'error');
      return;
    }

    showLoading(true);

    try {
      // Call new analyze-job endpoint that returns complete payload
      const response = await fetch('http://localhost:8000/api/analyze-job', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          job_description: currentJobDescription
        })
      });

      if (!response.ok) {
        throw new Error(`Backend error: ${response.statusText}`);
      }

      const jobAnalysis = await response.json();
      console.log('Job analysis complete:', jobAnalysis);

      // Store the full analysis for sending to app
      window.skillDeltaJobAnalysis = jobAnalysis;

      // Display skills
      if (jobAnalysis.skills && jobAnalysis.skills.length > 0) {
        displayResults(jobAnalysis.skills);
        updateStatus('Skills extracted successfully', 'success');
      } else {
        updateStatus('No skills extracted. Please try another job posting.', 'error');
      }
    } catch (error) {
      console.error('Error analyzing job description:', error);
      updateStatus('Failed to analyze. Please try again.', 'error');
    } finally {
      showLoading(false);
    }
  });

  clearBtn.addEventListener('click', () => {
    currentJobDescription = '';
    hideJobDisplay();
    updateStatus('Ready to analyze job descriptions', 'info');
  });

  newJobBtn.addEventListener('click', () => {
    currentJobDescription = '';
    hideJobDisplay();
    hideResults();
    updateStatus('Ready to analyze job descriptions', 'info');
  });

  sendToAppBtn.addEventListener('click', () => {
    // Get the complete job analysis payload
    const jobAnalysis = window.skillDeltaJobAnalysis || {
      skills: Array.from(document.querySelectorAll('.skillDelta-skill-tag')).map(el => el.textContent.trim()),
      job_title: 'Unknown',
      company_name: 'Unknown',
      job_description: currentJobDescription
    };

    console.log('Sending to main app:', jobAnalysis);

    // Send complete payload to main app
    chrome.runtime.sendMessage({
      action: 'sendJobAnalysisToApp',
      payload: jobAnalysis
    }).catch(error => {
      console.log('Main app not available. Payload:', jobAnalysis);
    });

    updateStatus('Job analysis sent to your profile!', 'success');
  });

  closeBtn.addEventListener('click', () => {
    const widget = document.getElementById('skillDelta-widget-container');
    widget.style.display = 'none';
  });
};

const extractAndDisplayJobDetails = async (jobText) => {
  try {
    console.log('Extracting job details...');
    const response = await fetch('http://localhost:8000/api/extract-job-details', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        job_description: jobText
      })
    });

    if (!response.ok) {
      throw new Error(`Backend error: ${response.statusText}`);
    }

    const jobDetails = await response.json();
    console.log('Job details extracted:', jobDetails);

    displayJobDetails(jobDetails);
  } catch (error) {
    console.error('Error extracting job details:', error);
    // Fallback: show raw text
    displayJobDescription(jobText);
  }
};

const displayJobDetails = (jobDetails) => {
  const jobDisplay = document.getElementById('skillDelta-job-display');
  const jobText = document.getElementById('skillDelta-job-text');
  const checkBtn = document.getElementById('skillDelta-check-clipboard-btn');

  // Create structured HTML for job details
  jobText.innerHTML = `
    <div class="skillDelta-job-detail-box">
      <div class="skillDelta-detail-field">
        <label class="skillDelta-detail-label">Position</label>
        <p class="skillDelta-detail-value">${escapeHtml(jobDetails.job_title || 'Unknown')}</p>
      </div>
      <div class="skillDelta-detail-field">
        <label class="skillDelta-detail-label">Company</label>
        <p class="skillDelta-detail-value">${escapeHtml(jobDetails.company || 'Unknown')}</p>
      </div>
      <div class="skillDelta-detail-field">
        <label class="skillDelta-detail-label">Description</label>
        <p class="skillDelta-detail-value">${escapeHtml(jobDetails.job_description || 'No description available')}</p>
      </div>
    </div>
  `;

  jobDisplay.style.display = 'block';
  checkBtn.style.display = 'none';
};

const displayJobDescription = (text) => {
  const jobDisplay = document.getElementById('skillDelta-job-display');
  const jobText = document.getElementById('skillDelta-job-text');
  const checkBtn = document.getElementById('skillDelta-check-clipboard-btn');

  jobText.innerHTML = `
    <div class="skillDelta-job-detail-box">
      <div class="skillDelta-detail-field">
        <label class="skillDelta-detail-label">Job Description</label>
        <p class="skillDelta-detail-value">${escapeHtml(text.substring(0, 300) + (text.length > 300 ? '...' : ''))}</p>
      </div>
    </div>
  `;
  jobDisplay.style.display = 'block';
  checkBtn.style.display = 'none';
};

const escapeHtml = (text) => {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
};

const hideJobDisplay = () => {
  document.getElementById('skillDelta-job-display').style.display = 'none';
  document.getElementById('skillDelta-check-clipboard-btn').style.display = 'block';
};

const displayResults = (skills) => {
  const results = document.getElementById('skillDelta-results');
  const skillsList = document.getElementById('skillDelta-skills-list');
  const jobDisplay = document.getElementById('skillDelta-job-display');

  skillsList.innerHTML = '';
  skills.forEach(skill => {
    const tag = document.createElement('span');
    tag.className = 'skillDelta-skill-tag';
    tag.textContent = skill;
    skillsList.appendChild(tag);
  });

  jobDisplay.style.display = 'none';
  results.style.display = 'block';
};

const hideResults = () => {
  document.getElementById('skillDelta-results').style.display = 'none';
};

const showLoading = (show) => {
  document.getElementById('skillDelta-loading').style.display = show ? 'block' : 'none';
};

const updateStatus = (message, type = 'info') => {
  const status = document.getElementById('skillDelta-status');
  status.textContent = message;
  status.className = `skillDelta-status skillDelta-status-${type}`;
};

// Initialize widget when DOM is ready
const initWidget = () => {
  try {
    console.log('SkillDelta: Initializing widget, DOM state:', document.readyState);
    if (document.body) {
      createWidget();
    } else {
      console.log('SkillDelta: Body not ready, waiting for DOMContentLoaded');
      document.addEventListener('DOMContentLoaded', createWidget);
    }
  } catch (error) {
    console.error('SkillDelta: Error initializing widget:', error);
  }
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initWidget);
} else {
  initWidget();
}
