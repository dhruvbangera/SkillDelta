// Offscreen document script for clipboard access in Manifest V3

console.log('SkillDelta offscreen document loaded');

// Add timeout for clipboard operations
const CLIPBOARD_TIMEOUT = 5000; // 5 seconds

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Offscreen received message:', request);

  if (request.type === 'clipboard' && request.target === 'offscreen') {
    console.log('Clipboard read requested');

    // Set a timeout to prevent hanging
    const timeoutId = setTimeout(() => {
      console.error('Clipboard read timeout');
      sendResponse({
        data: '',
        success: false,
        error: 'Clipboard read timeout - operation took too long'
      });
    }, CLIPBOARD_TIMEOUT);

    navigator.clipboard.readText()
      .then(text => {
        clearTimeout(timeoutId);
        console.log('Clipboard text read successfully, length:', text.length);
        if (text && text.trim().length > 0) {
          sendResponse({ data: text, success: true });
        } else {
          sendResponse({
            data: '',
            success: false,
            error: 'Clipboard is empty'
          });
        }
      })
      .catch(err => {
        clearTimeout(timeoutId);

        // Log full error object for debugging
        console.error('Clipboard read error in offscreen - Full error:', {
          name: err?.name,
          message: err?.message,
          stack: err?.stack,
          toString: err?.toString()
        });

        // Provide more helpful error messages based on error type
        let errorMsg = 'Failed to read clipboard';

        if (!err) {
          errorMsg = 'Unknown error occurred';
        } else if (err.name === 'NotAllowedError') {
          errorMsg = 'Clipboard access denied - please grant clipboard permissions to this extension';
        } else if (err.name === 'NotSupportedError') {
          errorMsg = 'Clipboard API not supported in this context';
        } else if (err.name === 'SecurityError') {
          errorMsg = 'Security error - unable to access clipboard in this context';
        } else if (err.name === 'AbortError') {
          errorMsg = 'Clipboard read was aborted';
        } else if (err.message) {
          // Use the actual error message if no specific type matched
          errorMsg = `Clipboard error: ${err.message}`;
        } else if (typeof err === 'string') {
          // Handle case where error is a string
          errorMsg = `Clipboard error: ${err}`;
        }

        console.log('Sending error response:', { errorMsg });

        sendResponse({
          data: '',
          success: false,
          error: errorMsg
        });
      });

    // Return true to indicate async response
    return true;
  }
});

console.log('SkillDelta offscreen document ready');
